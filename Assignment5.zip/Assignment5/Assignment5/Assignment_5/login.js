﻿const form = document.getElementById("myForm");
const formEntries = new FormData(form).entries();
const formData = Object.assign(...Array.from(formEntries, ([name, value]) => ({ [name]: value })));

console.log(formData)