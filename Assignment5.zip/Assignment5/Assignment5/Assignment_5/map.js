﻿function initMap() {
    var map = new google.maps.Map(document.getElementById('map'), { center: { lat: 40.74204772121962, lng: -74.0047166023409 }, zoom: 8 });
}